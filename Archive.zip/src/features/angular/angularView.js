import React from "react"


const AngularView = () => {


    return <div>
        <iframe className="iframeView" src="https://awik.io/determine-color-bright-dark-using-javascript/" />


    </div>
}

export default AngularView;