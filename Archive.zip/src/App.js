import React from 'react';
import { Tabs } from 'antd';
import { Counter } from './features/counter/Counter';
import './App.css';
import 'antd/dist/antd.css';
import AngularView from './features/angular/angularView';
import DashboardView from './features/dashboardview.js/dashboardView';

const { TabPane } = Tabs;
function App() {
  const onChange = (key) => {
    console.log(key);
  };
  
  return (
    <div className="App">
    
      <Tabs defaultActiveKey="1" onChange={onChange}>
    <TabPane tab="React with Redux" key="1">
      
    <Counter />
    </TabPane>
    <TabPane tab="React with Ant components" key="2">
     
    <DashboardView/>
    </TabPane>
    <TabPane tab="Angular View" key="3">
     
    <AngularView/>
    </TabPane>
  </Tabs>
  
    </div>
  );
}

export default App;
